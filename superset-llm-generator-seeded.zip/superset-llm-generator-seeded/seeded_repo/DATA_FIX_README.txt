This patched project seeds demo tables required by the generated dashboard:
- public.students
- public.grades

Fresh start:
1. docker compose down -v
2. docker compose up -d --build

Existing database volume:
Run the SQL manually, e.g.:
  docker exec -i superset_db psql -U superset -d superset < db/init/001_university_seed.sql
