-- Demo university data for Superset charts
-- Safe to run multiple times. Inserts rows only when tables are empty.

CREATE TABLE IF NOT EXISTS public.students (
    student_id BIGINT PRIMARY KEY,
    full_name TEXT NOT NULL,
    faculty TEXT NOT NULL,
    enrollment_date TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    gpa DOUBLE PRECISION NOT NULL,
    status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.grades (
    grade_id BIGINT PRIMARY KEY,
    student_id BIGINT NOT NULL REFERENCES public.students(student_id),
    course_name TEXT NOT NULL,
    score DOUBLE PRECISION NOT NULL,
    exam_date TIMESTAMP WITHOUT TIME ZONE NOT NULL
);

INSERT INTO public.students (student_id, full_name, faculty, enrollment_date, gpa, status)
SELECT
    s AS student_id,
    format('Student %s', lpad(s::text, 3, '0')) AS full_name,
    (ARRAY['Engineering', 'Economics', 'Medicine', 'Law'])[1 + ((s - 1) % 4)] AS faculty,
    (
      TIMESTAMP '2022-09-01 00:00:00'
      + make_interval(days => ((s - 1) % 900))
    ) AS enrollment_date,
    round((2.4 + ((s * 17) % 16) / 10.0)::numeric, 2)::double precision AS gpa,
    CASE
      WHEN s % 11 = 0 THEN 'graduated'
      WHEN s % 19 = 0 THEN 'expelled'
      ELSE 'active'
    END AS status
FROM generate_series(1, 120) AS s
WHERE NOT EXISTS (SELECT 1 FROM public.students);

INSERT INTO public.grades (grade_id, student_id, course_name, score, exam_date)
SELECT
    ((student_id - 1) * 4 + course_idx) AS grade_id,
    student_id,
    course_name,
    LEAST(100, GREATEST(45, base_score + ((student_id * 7 + course_idx * 9) % 18)))::double precision AS score,
    (
      TIMESTAMP '2023-01-15 00:00:00'
      + make_interval(days => ((student_id * 5 + course_idx * 23) % 720))
    ) AS exam_date
FROM (
    SELECT s AS student_id FROM generate_series(1, 120) AS s
) students
CROSS JOIN (
    VALUES
      (1, 'Mathematics', 68),
      (2, 'Physics', 64),
      (3, 'Economics', 71),
      (4, 'Literature', 73)
) AS courses(course_idx, course_name, base_score)
WHERE NOT EXISTS (SELECT 1 FROM public.grades);

CREATE INDEX IF NOT EXISTS idx_students_enrollment_date ON public.students (enrollment_date);
CREATE INDEX IF NOT EXISTS idx_students_faculty ON public.students (faculty);
CREATE INDEX IF NOT EXISTS idx_grades_exam_date ON public.grades (exam_date);
CREATE INDEX IF NOT EXISTS idx_grades_course_name ON public.grades (course_name);
CREATE INDEX IF NOT EXISTS idx_grades_student_id ON public.grades (student_id);
