CREATE TABLE IF NOT EXISTS public.students (
    student_id BIGINT PRIMARY KEY,
    full_name TEXT NOT NULL,
    faculty TEXT NOT NULL,
    enrollment_date TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    gpa DOUBLE PRECISION NOT NULL,
    status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.grades (
    grade_id BIGINT PRIMARY KEY,
    student_id BIGINT NOT NULL REFERENCES public.students(student_id),
    course_name TEXT NOT NULL,
    score DOUBLE PRECISION NOT NULL,
    exam_date TIMESTAMP WITHOUT TIME ZONE NOT NULL
);

INSERT INTO public.students (student_id, full_name, faculty, enrollment_date, gpa, status)
SELECT
    s AS student_id,
    format('Student %s', s) AS full_name,
    CASE s % 5
        WHEN 0 THEN 'Engineering'
        WHEN 1 THEN 'Mathematics'
        WHEN 2 THEN 'Physics'
        WHEN 3 THEN 'Economics'
        ELSE 'Computer Science'
    END AS faculty,
    timestamp '2021-09-01' + ((s - 1) % 30) * interval '30 days' AS enrollment_date,
    round((2.6 + ((s * 11) % 16) / 10.0)::numeric, 2)::double precision AS gpa,
    CASE
        WHEN s % 12 = 0 THEN 'expelled'
        WHEN s % 7 = 0 THEN 'graduated'
        ELSE 'active'
    END AS status
FROM generate_series(1, 60) AS s
WHERE NOT EXISTS (SELECT 1 FROM public.students LIMIT 1);

INSERT INTO public.grades (grade_id, student_id, course_name, score, exam_date)
SELECT
    ((st.student_id - 1) * 4 + c.idx) AS grade_id,
    st.student_id,
    c.course_name,
    round((55 + ((st.student_id * 9 + c.idx * 7) % 45))::numeric, 1)::double precision AS score,
    st.enrollment_date
        + (6 + c.idx * 5) * interval '30 days'
        + ((st.student_id % 5) * interval '3 days') AS exam_date
FROM public.students AS st
CROSS JOIN (
    VALUES
        (1, 'Mathematics'),
        (2, 'Physics'),
        (3, 'Computer Science'),
        (4, 'Statistics')
) AS c(idx, course_name)
WHERE NOT EXISTS (SELECT 1 FROM public.grades LIMIT 1);
