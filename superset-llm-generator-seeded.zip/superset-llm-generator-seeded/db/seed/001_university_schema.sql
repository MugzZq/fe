CREATE TABLE IF NOT EXISTS public.students (
    student_id BIGINT PRIMARY KEY,
    full_name TEXT NOT NULL,
    faculty TEXT NOT NULL,
    enrollment_date TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    gpa DOUBLE PRECISION NOT NULL,
    status TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS public.grades (
    grade_id BIGINT PRIMARY KEY,
    student_id BIGINT NOT NULL,
    course_name TEXT NOT NULL,
    score DOUBLE PRECISION NOT NULL,
    exam_date TIMESTAMP WITHOUT TIME ZONE NOT NULL,
    CONSTRAINT grades_student_fk FOREIGN KEY (student_id)
        REFERENCES public.students(student_id)
        ON DELETE CASCADE
);

INSERT INTO public.students (student_id, full_name, faculty, enrollment_date, gpa, status)
VALUES
    (1, 'Ivan Petrov', 'Engineering', '2023-09-01', 3.7, 'active'),
    (2, 'Maria Smirnova', 'Engineering', '2022-09-01', 3.9, 'active'),
    (3, 'Alexey Ivanov', 'Mathematics', '2021-09-01', 3.5, 'graduated'),
    (4, 'Elena Volkova', 'Mathematics', '2023-02-01', 4.0, 'active'),
    (5, 'Dmitry Sokolov', 'Physics', '2022-02-01', 3.2, 'active'),
    (6, 'Olga Orlova', 'Physics', '2021-02-01', 3.8, 'graduated'),
    (7, 'Nikita Fedorov', 'Economics', '2023-09-01', 3.4, 'active'),
    (8, 'Sofia Kuznetsova', 'Economics', '2022-09-01', 3.6, 'active'),
    (9, 'Pavel Morozov', 'Medicine', '2021-09-01', 3.3, 'expelled'),
    (10, 'Anna Lebedeva', 'Medicine', '2023-02-01', 3.95, 'active'),
    (11, 'Kirill Egorov', 'Law', '2022-02-01', 3.1, 'active'),
    (12, 'Vera Mikhailova', 'Law', '2021-02-01', 3.85, 'graduated')
ON CONFLICT (student_id) DO UPDATE
SET
    full_name = EXCLUDED.full_name,
    faculty = EXCLUDED.faculty,
    enrollment_date = EXCLUDED.enrollment_date,
    gpa = EXCLUDED.gpa,
    status = EXCLUDED.status;

INSERT INTO public.grades (grade_id, student_id, course_name, score, exam_date)
VALUES
    (101, 1, 'Calculus', 88, '2024-01-15'),
    (102, 1, 'Physics', 91, '2024-02-20'),
    (103, 1, 'Programming', 95, '2024-03-12'),
    (104, 2, 'Calculus', 92, '2024-01-17'),
    (105, 2, 'Physics', 89, '2024-02-21'),
    (106, 2, 'Programming', 97, '2024-03-10'),
    (107, 3, 'Linear Algebra', 84, '2023-12-19'),
    (108, 3, 'Statistics', 81, '2024-01-30'),
    (109, 3, 'Discrete Math', 86, '2024-02-18'),
    (110, 4, 'Linear Algebra', 96, '2024-01-11'),
    (111, 4, 'Statistics', 93, '2024-02-14'),
    (112, 4, 'Discrete Math', 94, '2024-03-01'),
    (113, 5, 'Mechanics', 76, '2024-01-09'),
    (114, 5, 'Optics', 79, '2024-02-05'),
    (115, 5, 'Thermodynamics', 74, '2024-03-07'),
    (116, 6, 'Mechanics', 90, '2023-12-22'),
    (117, 6, 'Optics', 87, '2024-01-26'),
    (118, 6, 'Thermodynamics', 85, '2024-02-28'),
    (119, 7, 'Microeconomics', 82, '2024-01-13'),
    (120, 7, 'Macroeconomics', 80, '2024-02-16'),
    (121, 7, 'Finance', 84, '2024-03-04'),
    (122, 8, 'Microeconomics', 86, '2024-01-18'),
    (123, 8, 'Macroeconomics', 88, '2024-02-19'),
    (124, 8, 'Finance', 90, '2024-03-06'),
    (125, 9, 'Anatomy', 69, '2023-12-15'),
    (126, 9, 'Biochemistry', 71, '2024-01-24'),
    (127, 9, 'Physiology', 67, '2024-02-27'),
    (128, 10, 'Anatomy', 94, '2024-01-08'),
    (129, 10, 'Biochemistry', 96, '2024-02-08'),
    (130, 10, 'Physiology', 93, '2024-03-03'),
    (131, 11, 'Civil Law', 78, '2024-01-12'),
    (132, 11, 'Criminal Law', 75, '2024-02-12'),
    (133, 11, 'Constitutional Law', 77, '2024-03-09'),
    (134, 12, 'Civil Law', 91, '2023-12-20'),
    (135, 12, 'Criminal Law', 89, '2024-01-28'),
    (136, 12, 'Constitutional Law', 92, '2024-02-29')
ON CONFLICT (grade_id) DO UPDATE
SET
    student_id = EXCLUDED.student_id,
    course_name = EXCLUDED.course_name,
    score = EXCLUDED.score,
    exam_date = EXCLUDED.exam_date;
