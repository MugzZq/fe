"""Pydantic models for the user-provided domain description YAML."""
from typing import Literal, Optional
from pydantic import BaseModel, Field


class ColumnSpec(BaseModel):
    name: str
    type: str  # e.g. BIGINT, TEXT, TIMESTAMP WITHOUT TIME ZONE
    is_dttm: bool = False
    groupby: bool = True
    filterable: bool = True
    description: Optional[str] = None


class MetricSpec(BaseModel):
    name: str
    verbose_name: str
    expression: str
    metric_type: str = "count"
    d3format: Optional[str] = None
    description: Optional[str] = None


class TableSpec(BaseModel):
    name: str
    schema_name: str = Field("public", alias="schema")
    main_dttm_col: Optional[str] = None
    description: Optional[str] = None
    columns: list[ColumnSpec]
    metrics: list[MetricSpec] = []

    model_config = {"populate_by_name": True}


class DatabaseSpec(BaseModel):
    name: str
    sqlalchemy_uri: str


class ChartSpec(BaseModel):
    title: str
    viz_type: Literal[
        "pie", "bar", "bar_categorical", "line", "table",
        "big_number", "box_plot", "area", "scatter",
    ]
    table: str  # references TableSpec.name
    groupby: list[str] = []
    metric: Optional[str] = None
    metrics: list[str] = []
    columns: list[str] = []       # for table viz
    x_axis: Optional[str] = None  # for time-series charts
    time_grain: str = "P1D"
    row_limit: int = 1000
    description: Optional[str] = None


class NativeFilterSpec(BaseModel):
    name: str
    column: str
    table: str
    filter_type: Literal["filter_select", "filter_range", "filter_time"] = "filter_select"
    multi_select: bool = True


class DomainSpec(BaseModel):
    domain_name: str = Field(alias="name")
    description: Optional[str] = None
    dashboard_title: str

    database: DatabaseSpec
    tables: list[TableSpec]
    charts: list[ChartSpec]
    native_filters: list[NativeFilterSpec] = []

    model_config = {"populate_by_name": True}
