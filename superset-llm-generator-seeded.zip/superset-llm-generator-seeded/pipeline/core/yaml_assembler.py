"""Parse LLM JSON response -> dict of {file_path: yaml_string}."""
import json
import yaml
from core.prompt_builder import extract_json_from_response


class AssemblyError(Exception):
    """Raised when LLM output cannot be parsed into valid YAML files."""
    pass


_REQUIRED_PREFIXES = ("metadata.yaml", "databases/", "datasets/", "charts/", "dashboards/")

# In Superset 3.1.3 import YAML, most structured fields should remain YAML dicts/lists.
# The only field we normalize to JSON string is chart query_context.
_JSON_STRING_FIELDS = {
    "charts/": ["query_context"],
}


def _fix_json_string_fields(path: str, data: dict) -> dict:
    """Convert dict-valued fields that Superset expects as JSON strings."""
    for prefix, fields in _JSON_STRING_FIELDS.items():
        if path.startswith(prefix):
            for field in fields:
                if field in data and isinstance(data[field], (dict, list)):
                    data[field] = json.dumps(data[field], ensure_ascii=False)
    return data


def _sanitize_for_superset_3_1_3(path: str, data: dict) -> dict:
    """Normalize fields that are incompatible with Superset 3.1.3 import schemas."""
    if path.startswith("databases/"):
        data.pop("impersonate_user", None)
        extra = data.get("extra")
        if isinstance(extra, dict) and "schemas_allowed_for_file_upload" in extra:
            extra["schemas_allowed_for_csv_upload"] = extra.pop(
                "schemas_allowed_for_file_upload"
            )

    if path.startswith("datasets/"):
        data.pop("catalog", None)

    return data


def _validate_dashboard_native_filters(path: str, data: dict) -> list[str]:
    """Return validation errors for dashboard native filters."""
    issues: list[str] = []
    if not path.startswith("dashboards/") or not isinstance(data, dict):
        return issues

    native_filters = data.get("metadata", {}).get("native_filter_configuration", [])
    for i, native_filter in enumerate(native_filters, start=1):
        for j, target in enumerate(native_filter.get("targets", []), start=1):
            if "datasetId" in target and "datasetUuid" not in target:
                issues.append(
                    f"native_filter_configuration[{i}].targets[{j}] uses datasetId; "
                    "Superset 3.1.3 import expects datasetUuid"
                )
    return issues


def assemble_files(llm_response: str) -> dict[str, str]:
    """
    Extract JSON from LLM response, parse each value as YAML, normalize field types,
    and return a dict of {relative_path: yaml_string}.
    Raises AssemblyError with details if validation fails.
    """
    try:
        raw_json = extract_json_from_response(llm_response)
    except ValueError as e:
        raise AssemblyError(f"Could not extract JSON from response: {e}") from e

    try:
        files: dict = json.loads(raw_json)
    except json.JSONDecodeError as e:
        raise AssemblyError(f"Invalid JSON in LLM response: {e}") from e

    if not isinstance(files, dict):
        raise AssemblyError("Expected a JSON object, got something else")

    errors = {}
    validated: dict[str, str] = {}

    for path, content in files.items():
        if not isinstance(content, str):
            errors[path] = f"Value must be a YAML string, got {type(content).__name__}"
            continue
        try:
            parsed = yaml.safe_load(content)
        except yaml.YAMLError as e:
            errors[path] = f"Invalid YAML: {e}"
            continue
        if parsed is None:
            errors[path] = "YAML parsed to None (empty document)"
            continue

        if isinstance(parsed, dict):
            parsed = _sanitize_for_superset_3_1_3(path, parsed)
            parsed = _fix_json_string_fields(path, parsed)
            dashboard_issues = _validate_dashboard_native_filters(path, parsed)
            if dashboard_issues:
                errors[path] = "; ".join(dashboard_issues)
                continue
            content = yaml.dump(parsed, allow_unicode=True, sort_keys=False)

        validated[path] = content

    present = set(validated.keys())
    for prefix in _REQUIRED_PREFIXES:
        if not any(p.startswith(prefix) for p in present):
            errors[f"missing:{prefix}"] = f"No file with prefix '{prefix}' was generated"

    if errors:
        raise AssemblyError(
            "Assembly validation failed:\n"
            + "\n".join(f"  {k}: {v}" for k, v in errors.items())
        )

    return validated


def merge_corrections(original: dict[str, str], corrections: dict[str, str]) -> dict[str, str]:
    """Merge corrected files into the original bundle (corrected files override)."""
    return {**original, **corrections}
