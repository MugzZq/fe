"""Build a Superset-importable ZIP bundle from a dict of YAML files."""
import io
import zipfile
from pathlib import Path


_ROOT = "bundle"


def build_zip(files: dict[str, str]) -> bytes:
    """
    Pack files into a ZIP with a single root directory 'bundle/'.
    Superset's remove_root() strips this prefix before processing.
    """
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel_path, content in files.items():
            zf.writestr(f"{_ROOT}/{rel_path}", content.encode("utf-8"))
    return buf.getvalue()


def save_zip(zip_bytes: bytes, output_dir: str, name: str) -> Path:
    """Write ZIP bytes to disk and return the path."""
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    dest = out / f"{name}.zip"
    dest.write_bytes(zip_bytes)
    return dest
