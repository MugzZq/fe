"""Parse and validate the user-provided domain YAML into a DomainSpec."""
import uuid
import yaml
from pathlib import Path
from schemas.input_schema import DomainSpec


# Namespace for deterministic UUIDs — stable across runs for same input
_NS = uuid.UUID("6ba7b810-9dad-11d1-80b4-00c04fd430c8")  # uuid.NAMESPACE_URL


def _uuid5(key: str) -> str:
    return str(uuid.uuid5(_NS, key))


def parse_input(path: str) -> dict:
    """
    Returns a dict with:
      - spec: DomainSpec
      - uuids: {
          "database": str,
          "datasets": {table_name: str},
          "charts": {chart_title: str},
          "dashboard": str,
        }
    """
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))

    # Support both flat dict and nested {domain: ..., database: ..., ...}
    if "domain" in raw:
        flat = {**raw.pop("domain"), **raw}
    else:
        flat = raw

    spec = DomainSpec.model_validate(flat)
    domain = spec.domain_name

    uuids = {
        "database": _uuid5(f"{domain}:database:{spec.database.name}"),
        "datasets": {
            t.name: _uuid5(f"{domain}:dataset:{t.name}") for t in spec.tables
        },
        "charts": {
            c.title: _uuid5(f"{domain}:chart:{c.title}") for c in spec.charts
        },
        "dashboard": _uuid5(f"{domain}:dashboard:{spec.dashboard_title}"),
    }

    return {"spec": spec, "uuids": uuids}
