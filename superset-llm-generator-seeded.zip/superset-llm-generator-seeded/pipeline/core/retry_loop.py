"""
Main pipeline orchestration:
  domain spec → LLM → YAML files → ZIP → Superset import
  On error: feed error back to LLM → retry (up to max_attempts)
"""
import logging
from pathlib import Path

from config import settings
from core.llm_client import call_claude
from core.prompt_builder import build_initial_prompt, build_retry_prompt
from core.yaml_assembler import assemble_files, AssemblyError
from core.zip_builder import build_zip, save_zip
from core.superset_client import SupersetClient

log = logging.getLogger(__name__)


def run_pipeline(parsed: dict) -> dict:
    """
    Execute the full generate → import → retry loop.

    Args:
        parsed: output of core.parser.parse_input()

    Returns:
        {"status": "success", "attempt": N, "zip_path": str}
    """
    spec = parsed["spec"]
    uuids = parsed["uuids"]
    client = SupersetClient()

    # Determine the database YAML filename (used for passwords field)
    db_filename = f"{spec.database.name}.yaml"

    system, user = build_initial_prompt(spec, uuids)
    files: dict[str, str] | None = None
    error_context = None

    for attempt in range(1, settings.max_retry_attempts + 1):
        log.info("Attempt %d/%d — calling Claude...", attempt, settings.max_retry_attempts)

        if attempt > 1 and error_context is not None:
            system, user = build_retry_prompt(system, user, files or {}, error_context)

        # 1. Call LLM
        try:
            llm_response = call_claude(system, user)
        except Exception as e:
            log.error("LLM call failed: %s", e)
            raise

        # 2. Parse + validate YAML from response
        try:
            files = assemble_files(llm_response)
        except AssemblyError as e:
            log.warning("Assembly error on attempt %d: %s", attempt, e)
            error_context = {"assembly_error": str(e)}
            continue

        log.info("Generated %d files: %s", len(files), list(files.keys()))

        # 3. Build ZIP
        zip_bytes = build_zip(files)
        zip_path = save_zip(
            zip_bytes,
            settings.output_dir,
            f"dashboard_attempt_{attempt}",
        )
        log.info("ZIP saved: %s (%d bytes)", zip_path, len(zip_bytes))

        # 4. Import into Superset
        status, body = client.import_dashboard(
            zip_bytes=zip_bytes,
            db_password=settings.db_password,
            db_filename=db_filename,
            overwrite=True,
        )

        if status == 200:
            log.info("Import successful on attempt %d", attempt)
            return {
                "status": "success",
                "attempt": attempt,
                "zip_path": str(zip_path),
            }

        if status == 422:
            error_context = client.extract_import_errors(body)
            log.warning(
                "Import validation error on attempt %d: %s",
                attempt,
                error_context,
            )
            # Save failed ZIP for debugging
            save_zip(zip_bytes, settings.output_dir, f"dashboard_attempt_{attempt}_FAILED")
            continue

        # Unexpected HTTP error
        log.error("Unexpected HTTP %d from Superset: %s", status, body)
        raise RuntimeError(f"Superset returned HTTP {status}: {body}")

    raise RuntimeError(
        f"Pipeline failed after {settings.max_retry_attempts} attempts. "
        f"Last error: {error_context}"
    )
