"""Build prompts for Claude from a parsed domain spec."""
import re
import yaml
from pathlib import Path
from schemas.input_schema import DomainSpec


def _load_system_prompt() -> str:
    path = Path(__file__).parent.parent / "templates" / "system_prompt.txt"
    return path.read_text(encoding="utf-8")


def build_initial_prompt(spec: DomainSpec, uuids: dict) -> tuple[str, str]:
    """Return (system_prompt, user_prompt) for first generation attempt."""
    system = _load_system_prompt()

    domain_data = {
        "domain_name": spec.domain_name,
        "description": spec.description,
        "dashboard_title": spec.dashboard_title,
        "database": {
            "name": spec.database.name,
            "sqlalchemy_uri": spec.database.sqlalchemy_uri,
            "uuid": uuids["database"],
        },
        "tables": [
            {
                "name": t.name,
                "schema": t.schema_name,
                "main_dttm_col": t.main_dttm_col,
                "description": t.description,
                "uuid": uuids["datasets"][t.name],
                "columns": [c.model_dump() for c in t.columns],
                "metrics": [m.model_dump() for m in t.metrics],
            }
            for t in spec.tables
        ],
        "charts": [
            {
                "title": c.title,
                "uuid": uuids["charts"][c.title],
                "viz_type": c.viz_type,
                "table": c.table,
                "table_uuid": uuids["datasets"][c.table],
                "groupby": c.groupby,
                "metric": c.metric,
                "metrics": c.metrics,
                "columns": c.columns,
                "x_axis": c.x_axis,
                "time_grain": c.time_grain,
                "row_limit": c.row_limit,
                "description": c.description,
            }
            for c in spec.charts
        ],
        "native_filters": [f.model_dump() for f in spec.native_filters],
        "uuids": uuids,
    }

    user = (
        "Generate all Superset YAML files for the following domain specification.\n\n"
        "```yaml\n"
        + yaml.dump(domain_data, allow_unicode=True, sort_keys=False)
        + "```\n\n"
        "Output ONLY the <json>...</json> block as described in the system prompt."
    )

    return system, user


def build_retry_prompt(
    system: str,
    original_user: str,
    previous_files: dict[str, str],
    errors: list | dict,
) -> tuple[str, str]:
    """Return updated prompts incorporating the Superset import error."""
    error_yaml = yaml.dump(errors, allow_unicode=True, default_flow_style=False)

    # Include the previously generated files so Claude has context
    prev_yaml = yaml.dump(
        {k: v[:500] + "..." if len(v) > 500 else v for k, v in previous_files.items()},
        allow_unicode=True,
    )

    retry_user = (
        original_user
        + "\n\n---\n"
        "The previous import attempt failed with these Superset validation errors:\n"
        "```yaml\n"
        + error_yaml
        + "```\n\n"
        "Previously generated files (truncated for context):\n"
        "```yaml\n"
        + prev_yaml
        + "```\n\n"
        "Please output the COMPLETE corrected JSON bundle (all files, not just changed ones)."
    )

    return system, retry_user


def extract_json_from_response(text: str) -> str:
    """Extract JSON string from <json>...</json> or ```json ... ``` block."""
    # Try <json> tags first
    m = re.search(r"<json>(.*?)</json>", text, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Try ```json fenced block
    m = re.search(r"```(?:json)?\s*([\[{].*?)```", text, re.DOTALL)
    if m:
        return m.group(1).strip()

    # Last resort: find first { to last }
    start = text.find("{")
    end = text.rfind("}")
    if start != -1 and end != -1:
        return text[start : end + 1]

    raise ValueError("Could not extract JSON from LLM response")
