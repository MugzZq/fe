"""Superset REST API client: auth + CSRF + dashboard import."""
import json
import requests
from config import settings


class SupersetImportError(Exception):
    """Raised when Superset returns HTTP 4xx/5xx during import."""
    def __init__(self, status: int, body: dict):
        self.status = status
        self.body = body
        super().__init__(f"HTTP {status}: {json.dumps(body, ensure_ascii=False)[:500]}")


class SupersetClient:
    def __init__(self):
        self.base_url = settings.superset_url.rstrip("/")
        self.session = requests.Session()
        self._token: str | None = None
        self._csrf_token: str | None = None

    def _login(self) -> str:
        resp = self.session.post(
            f"{self.base_url}/api/v1/security/login",
            json={
                "username": settings.superset_username,
                "password": settings.superset_password,
                "provider": "db",
                "refresh": True,
            },
            timeout=30,
        )
        resp.raise_for_status()
        token = resp.json()["access_token"]
        self.session.headers.update(
            {
                "Authorization": f"Bearer {token}",
                "Accept": "application/json",
            }
        )
        return token

    @property
    def token(self) -> str:
        if self._token is None:
            self._token = self._login()
        return self._token

    def _get_csrf_token(self) -> str:
        _ = self.token
        resp = self.session.get(
            f"{self.base_url}/api/v1/security/csrf_token/",
            timeout=30,
        )
        resp.raise_for_status()
        payload = resp.json()
        token = payload.get("result") or payload.get("csrf_token")
        if not token:
            raise SupersetImportError(resp.status_code, payload)
        self.session.headers.update(
            {
                "X-CSRFToken": token,
                "Referer": f"{self.base_url}/",
            }
        )
        return token

    @property
    def csrf_token(self) -> str:
        if self._csrf_token is None:
            self._csrf_token = self._get_csrf_token()
        return self._csrf_token

    def import_dashboard(
        self,
        zip_bytes: bytes,
        db_password: str,
        db_filename: str,
        overwrite: bool = True,
    ) -> tuple[int, dict]:
        """
        POST /api/v1/dashboard/import/
        Returns (status_code, response_json).

        Superset 3.x expects POST requests to carry the CSRF token and the same
        session/cookies used to obtain it.
        """
        _ = self.csrf_token

        files = {"formData": ("bundle.zip", zip_bytes, "application/zip")}
        data = {
            "overwrite": str(overwrite).lower(),
            "passwords": json.dumps({f"databases/{db_filename}": db_password}),
        }
        resp = self.session.post(
            f"{self.base_url}/api/v1/dashboard/import/",
            files=files,
            data=data,
            timeout=120,
        )

        try:
            body = resp.json()
        except Exception:
            body = {"raw": resp.text}

        return resp.status_code, body

    def extract_import_errors(self, body: dict) -> dict:
        """
        Parse the 422 error body from Superset into a flat errors dict.
        Returns {file_path: {field: [messages]}} or the raw errors list.
        """
        errors = body.get("errors", [])
        result = {}
        for err in errors:
            extra = err.get("extra", {})
            messages = extra.get("messages", {})
            if messages:
                result.update(messages)
            else:
                result["general"] = err.get("message", str(err))
        return result if result else {"raw": errors}
