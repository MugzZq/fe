"""Anthropic API client with retry logic."""
import anthropic
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type
from config import settings


_client = anthropic.Anthropic(api_key=settings.anthropic_api_key)


@retry(
    retry=retry_if_exception_type((anthropic.RateLimitError, anthropic.APITimeoutError)),
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=2, min=5, max=60),
)
def call_claude(system: str, user: str) -> str:
    """Call Claude and return the text of the first content block."""
    message = _client.messages.create(
        model=settings.claude_model,
        max_tokens=8192,
        system=system,
        messages=[{"role": "user", "content": user}],
    )
    return message.content[0].text
