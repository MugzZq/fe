from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    anthropic_api_key: str
    superset_url: str = "http://superset:8088"
    superset_username: str = "admin"
    superset_password: str = "admin"
    db_password: str = "superset"
    max_retry_attempts: int = 3
    input_file: str = "/app/input/domain.yaml"
    output_dir: str = "/app/output"
    claude_model: str = "claude-opus-4-6"


settings = Settings()
