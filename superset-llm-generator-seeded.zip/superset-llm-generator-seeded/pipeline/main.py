"""Entry point for the Superset dashboard generation pipeline."""
import argparse
import logging
import sys

from config import settings
from core.parser import parse_input
from core.retry_loop import run_pipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stdout,
)
log = logging.getLogger(__name__)


def main():
    parser = argparse.ArgumentParser(
        description="Generate and import a Superset dashboard from a domain spec YAML."
    )
    parser.add_argument(
        "--input",
        default=settings.input_file,
        help="Path to the domain spec YAML file",
    )
    args = parser.parse_args()

    log.info("Reading domain spec from: %s", args.input)
    try:
        parsed = parse_input(args.input)
    except Exception as e:
        log.error("Failed to parse domain spec: %s", e)
        sys.exit(1)

    spec = parsed["spec"]
    log.info(
        "Domain: %s | Dashboard: %s | Tables: %d | Charts: %d",
        spec.domain_name,
        spec.dashboard_title,
        len(spec.tables),
        len(spec.charts),
    )

    try:
        result = run_pipeline(parsed)
    except Exception as e:
        log.error("Pipeline failed: %s", e)
        sys.exit(1)

    log.info(
        "Done! status=%s attempt=%d zip=%s",
        result["status"],
        result["attempt"],
        result["zip_path"],
    )


if __name__ == "__main__":
    main()
